﻿using UnityEngine.Purchasing;


namespace Code.IAP.AppShop
{
    public class ShopProduct
    {
        public string Id;
        public ProductType CurrentProductType;
    }
}