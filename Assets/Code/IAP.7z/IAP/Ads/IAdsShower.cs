﻿using System;


namespace Code.IAP.Ads
{
    public interface IAdsShower
    {
        void ShowInterstitial();
        void ShowVideo(Action successShow);
    }
}